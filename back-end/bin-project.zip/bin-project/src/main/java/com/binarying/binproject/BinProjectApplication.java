package com.binarying.binproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BinProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BinProjectApplication.class, args);
	}

}
